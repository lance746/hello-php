<body>
<?php echo "READY"; ?>
</body>
</html>
